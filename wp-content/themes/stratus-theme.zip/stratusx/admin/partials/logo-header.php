<?php
	$logo_setup = get_template_directory_uri() . '/assets/images/stratus-logo-circle.png';
	$logo_title = get_template_directory_uri() . '/assets/images/logo.png';
?>

<img src='<?php echo $logo_setup; ?>' alt='Stratus Logo'>
<img src='<?php echo $logo_title; ?>' alt='Stratus'>
